# VT Download Monitor

Watches a folder (e.g. `Downloads`), hashes every new or edited file, checks/uploads it to VirusTotal, and tells you if it's clean or malicious. Results are auto-saved to a report file, and previously scanned files are remembered so they aren't re-uploaded.

## Requirements

```bash
pip install watchdog requests
```

You also need a free VirusTotal API key: https://www.virustotal.com/gui/my-apikey

## Setup

```bash
export VT_API_KEY="your_virustotal_api_key"
```

(Windows PowerShell: `$env:VT_API_KEY="your_virustotal_api_key"`)

## Run syntax

**Foreground** (stops when you close the terminal):
```bash
python3 vt_download_monitor.py [/path/to/Downloads]
```
If no path is given, it defaults to `~/Downloads`.

**Background** (keeps running after you close the terminal — Linux/Mac only):
```bash
python3 vt_download_monitor.py [/path/to/Downloads] --daemon
```

**Stop the background monitor:**
```bash
python3 vt_download_monitor.py --stop
```

## Output files

All saved next to the script:

| File | What it is |
|---|---|
| `vt_scan_report.txt` | Human-readable log of every scan (time, file, verdict, link) — appended, never overwritten |
| `vt_scan_records.json` | Hash → result cache. Prevents re-scanning the same file content twice |
| `vt_monitor.pid` | Process ID of the background instance (only exists in `--daemon` mode) |
| `vt_monitor.log` | stdout/stderr of the background instance (only in `--daemon` mode) |

## Examples

```bash
# scan your Downloads folder in the foreground
python3 vt_download_monitor.py ~/Downloads

# scan a custom folder in the background
python3 vt_download_monitor.py /home/user/Desktop/incoming --daemon

# stop it
python3 vt_download_monitor.py --stop
```

## Notes

- `--daemon` uses a Unix double-fork, so it only works on Linux/Mac. On Windows, run it in the foreground (e.g. inside a detached `pythonw.exe` process or via Task Scheduler) — ask if you want a Windows-specific version.
- Files larger than 32MB are skipped for upload (VirusTotal public API limit) but still checked against VT's existing database by hash.
- Browser temp extensions (`.crdownload`, `.part`, `.tmp`) are ignored until the download finishes.
