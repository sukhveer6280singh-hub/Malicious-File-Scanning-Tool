#!/usr/bin/env python3
"""
Download Directory Monitor + VirusTotal Scanner
Watches a folder, hashes new/edited files, checks/uploads to VirusTotal, saves results.

Usage:
    export VT_API_KEY="APi key here"

    # normal (foreground, stops if you close the terminal)
    python3 vt_download_monitor.py [/path/to/Downloads]

    # background (keeps running after you close the terminal)
    python3 vt_download_monitor.py [/path/to/Downloads] --daemon

    # stop the background monitor
    python3 vt_download_monitor.py --stop

When run with --daemon, logs go to vt_monitor.log and the process id is
saved to vt_monitor.pid (both next to this script). Scan results always
go to vt_scan_report.txt, and known file hashes are cached in
vt_scan_records.json so repeated files aren't re-uploaded.
"""

import os
import sys
import time
import json
import signal
import hashlib
import threading
import requests
from datetime import datetime
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

VT_API_KEY = os.environ.get("VT_API_KEY", "")
VT_BASE = "https://www.virustotal.com/api/v3"

# separate real flags from the watch-dir positional argument
_ARGS = sys.argv[1:]
RUN_AS_DAEMON = "--daemon" in _ARGS
STOP_DAEMON = "--stop" in _ARGS
_POSITIONAL = [a for a in _ARGS if not a.startswith("--")]

WATCH_DIR = _POSITIONAL[0] if _POSITIONAL else os.path.expanduser("~/Downloads")
SETTLE_SECS = 2          # wait for file write to finish
POLL_INTERVAL = 15       # secs between analysis polls
MAX_UPLOAD_MB = 32       # VT public API upload limit

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# where results are remembered/saved
RECORD_FILE = os.path.join(_SCRIPT_DIR, "vt_scan_records.json")
REPORT_FILE = os.path.join(_SCRIPT_DIR, "vt_scan_report.txt")

# background-mode files: process id + log (since terminal will be closed)
PID_FILE = os.path.join(_SCRIPT_DIR, "vt_monitor.pid")
LOG_FILE = os.path.join(_SCRIPT_DIR, "vt_monitor.log")

# debounce so rapid edit-events on the same file don't trigger duplicate scans
DEBOUNCE_SECS = 3
_last_seen = {}
_lock = threading.Lock()

# hash -> last known result, loaded at startup, overwritten after every scan
_records = {}


def load_records():
    global _records
    if os.path.isfile(RECORD_FILE):
        try:
            with open(RECORD_FILE, "r") as f:
                _records = json.load(f)
        except (json.JSONDecodeError, OSError):
            _records = {}
    else:
        _records = {}


def save_records():
    # overwrite the whole file with the current in-memory record set
    with open(RECORD_FILE, "w") as f:
        json.dump(_records, f, indent=2)


def append_report(entry_text):
    with open(REPORT_FILE, "a") as f:
        f.write(entry_text + "\n")


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def vt_headers():
    return {"x-apikey": VT_API_KEY}


def get_report(file_hash):
    r = requests.get(f"{VT_BASE}/files/{file_hash}", headers=vt_headers())
    if r.status_code == 200:
        return r.json()
    return None


def upload_file(path):
    size_mb = os.path.getsize(path) / (1024 * 1024)
    if size_mb > MAX_UPLOAD_MB:
        print(f"[!] {path} is {size_mb:.1f}MB > {MAX_UPLOAD_MB}MB limit, skipping upload")
        return None
    with open(path, "rb") as f:
        r = requests.post(f"{VT_BASE}/files", headers=vt_headers(), files={"file": f})
    if r.status_code == 200:
        return r.json()["data"]["id"]  # analysis id
    print(f"[!] upload failed: {r.status_code} {r.text}")
    return None


def poll_analysis(analysis_id):
    while True:
        r = requests.get(f"{VT_BASE}/analyses/{analysis_id}", headers=vt_headers())
        data = r.json()
        status = data["data"]["attributes"]["status"]
        if status == "completed":
            return data
        time.sleep(POLL_INTERVAL)


def build_result_block(filename, stats, link=None, cached=False, event_type="new"):
    malicious = stats.get("malicious", 0)
    suspicious = stats.get("suspicious", 0)
    undetected = stats.get("undetected", 0)
    harmless = stats.get("harmless", 0)
    total = malicious + suspicious + undetected + harmless
    verdict = "MALICIOUS" if malicious > 0 else ("SUSPICIOUS" if suspicious > 0 else "CLEAN")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "=" * 60,
        f"Time     : {ts}",
        f"Event    : {event_type}{'  (cached result)' if cached else ''}",
        f"File     : {filename}",
        f"Score    : {malicious}/{total} engines flagged malicious",
        f"Suspicious: {suspicious}  Harmless: {harmless}  Undetected: {undetected}",
        f"Verdict  : {verdict}",
    ]
    if link:
        lines.append(f"Report   : {link}")
    lines.append("=" * 60)
    return verdict, "\n".join(lines)


def print_result(filename, stats, link=None, cached=False, event_type="new"):
    verdict, block = build_result_block(filename, stats, link, cached, event_type)
    print(block)
    append_report(block)
    return verdict


def scan_file(path, event_type="new"):
    if not os.path.isfile(path):
        return
    filename = os.path.basename(path)

    # debounce: skip if we already handled this exact path a moment ago
    # (edits/saves often fire several filesystem events back to back)
    with _lock:
        now = time.time()
        last = _last_seen.get(path, 0)
        if now - last < DEBOUNCE_SECS:
            return
        _last_seen[path] = now

    print(f"[+] {event_type.capitalize()} file detected: {filename}")
    time.sleep(SETTLE_SECS)  # let the write finish (browsers write .crdownload/.part then rename)

    try:
        file_hash = sha256_of(path)
    except (PermissionError, FileNotFoundError):
        return

    link = f"https://www.virustotal.com/gui/file/{file_hash}"

    # if we've already scanned this exact content before, reuse that result
    # instead of hitting the API again
    if file_hash in _records:
        stats = _records[file_hash]["stats"]
        verdict = print_result(filename, stats, link, cached=True, event_type=event_type)
        _records[file_hash].update({"filename": filename, "path": path, "last_seen": event_type})
        save_records()
        return

    report = get_report(file_hash)
    if report:
        stats = report["data"]["attributes"]["last_analysis_stats"]
        verdict = print_result(filename, stats, link, event_type=event_type)
        _records[file_hash] = {"filename": filename, "path": path, "stats": stats,
                                "verdict": verdict, "last_seen": event_type}
        save_records()
        return

    print(f"[+] Not in VT database, uploading {filename} ...")
    analysis_id = upload_file(path)
    if not analysis_id:
        return
    result = poll_analysis(analysis_id)
    stats = result["data"]["attributes"]["stats"]
    verdict = print_result(filename, stats, link, event_type=event_type)
    _records[file_hash] = {"filename": filename, "path": path, "stats": stats,
                            "verdict": verdict, "last_seen": event_type}
    save_records()


class DownloadHandler(FileSystemEventHandler):
    def on_created(self, event):
        if event.is_directory:
            return
        # skip browser temp files
        if event.src_path.endswith((".crdownload", ".part", ".tmp")):
            return
        scan_file(event.src_path, event_type="new")

    def on_moved(self, event):
        # covers browsers renaming .crdownload -> final filename
        if event.is_directory:
            return
        scan_file(event.dest_path, event_type="new")

    def on_modified(self, event):
        # file content changed/edited after creation
        if event.is_directory:
            return
        if event.src_path.endswith((".crdownload", ".part", ".tmp")):
            return
        scan_file(event.src_path, event_type="edited")


def daemonize():
    """
    Standard Unix double-fork so the process detaches fully from the
    terminal: closing the terminal window will NOT kill it.
    """
    # first fork
    if os.fork() > 0:
        sys.exit(0)  # parent exits, first child continues

    os.setsid()  # start a new session, detach from controlling terminal

    # second fork so the process can never re-acquire a controlling terminal
    if os.fork() > 0:
        sys.exit(0)

    # redirect stdin/stdout/stderr away from the (soon to be closed) terminal
    sys.stdout.flush()
    sys.stderr.flush()
    devnull = open(os.devnull, "r")
    logf = open(LOG_FILE, "a", buffering=1)
    os.dup2(devnull.fileno(), sys.stdin.fileno())
    os.dup2(logf.fileno(), sys.stdout.fileno())
    os.dup2(logf.fileno(), sys.stderr.fileno())

    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))


def stop_daemon():
    if not os.path.isfile(PID_FILE):
        print("[!] No running background monitor found (no pid file).")
        return
    with open(PID_FILE, "r") as f:
        pid = int(f.read().strip())
    try:
        os.kill(pid, signal.SIGTERM)
        print(f"[*] Stopped background monitor (pid {pid}).")
    except ProcessLookupError:
        print("[!] Process not running, cleaning up stale pid file.")
    os.remove(PID_FILE)



def main():
    if STOP_DAEMON:
        stop_daemon()
        sys.exit(0)

    if not VT_API_KEY:
        print("[!] Set VT_API_KEY env var first: export VT_API_KEY='your_key'")
        sys.exit(1)
    if not os.path.isdir(WATCH_DIR):
        print(f"[!] Directory not found: {WATCH_DIR}")
        sys.exit(1)

    if RUN_AS_DAEMON:
        print(f"[*] Starting in background. Logs -> {LOG_FILE}")
        daemonize()

    observer = Observer()

    def _handle_sigterm(signum, frame):
        observer.stop()

    signal.signal(signal.SIGTERM, _handle_sigterm)

    load_records()
    print(f"[*] Monitoring: {WATCH_DIR}")
    print(f"[*] Report file : {REPORT_FILE}")
    print(f"[*] Record cache: {RECORD_FILE}")
    observer.schedule(DownloadHandler(), WATCH_DIR, recursive=False)
    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()


if __name__ == "__main__":
    main()
